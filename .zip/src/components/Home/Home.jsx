import React from 'react'
import axios from 'axios'

function Home() {
    
  

  return (
    <div>Home</div>
  )
}

export default Home